const { handleValidationErrors, getUserDetails } = require('./common');

module.exports = { handleValidationErrors, getUserDetails };