module.exports = {
    userRegistration: require('./userRegistration'),
    login: require('./login'),
    passwordController: require('./forgetpassword'),
    storyController: require('./story'),
};